import Component from './words-counter/component.js';

// Register Words Counter component.
$e.components.register( new Component );
